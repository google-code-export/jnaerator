package org.anarres.cpp;

import junit.framework.TestCase;

public abstract class BaseTestCase extends TestCase {
}
